<?php
	require('../classes/session.php');
	require('../config/db.php');
	require('../model/model.php');
	require('../classes/validation.php');
	
	Session::init();

	if(!Session::checkSession('email')){
		header("location:index.php");
	}

	$post_value = [
		["full_name","required"]
	];

	$validate = new Validation($post_value);

	// check validation
	if($validate->isError()){
		echo $validate->isError();
	}
	else{
		$where = "email='".Session::getValue("email")."'";

		$db = new Model();
		$user_data = $db->update("users",$_POST,$where);
		if($user_data){
			header("location:profile.php");
		}
		else {
			header("location:update.php");
		}
	}



	

?>
