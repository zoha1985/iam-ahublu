<?php
	require('../classes/session.php');
	require('../config/db.php');
	require('../model/model.php');
	require('../classes/views.php');
	
	Session::init();

	if(!Session::checkSession('email')){
		header("location:index.php");
	}

	$where = "email='".Session::getValue("email")."'";

	$db = new Model();
	$user_data = $db->select("admin","*",$where);

	$view = new Views();
	$view->render("dashboard",$user_data,"admin/");
?>
