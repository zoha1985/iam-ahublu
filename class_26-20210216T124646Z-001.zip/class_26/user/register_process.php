<?php
	require('../config/db.php');
	require('../model/model.php');
	require('../classes/validation.php');

	// velidation rules
	$post_value = [
		["full_name","required"],
		["email","required:email"],
		["pass","required:password"]
	];

	$validate = new Validation($post_value);

	// check validation
	if($validate->isError()){
		echo $validate->isError();
	}
	else{
		$db = new Model();
		$where = "email='".$_REQUEST['email']."'"; //"email='abc@gmail.com'"
		$get_email = $db->select("users","email",$where);

		// check email-----
		if($get_email['count'] < 1){
			// $options = [
   //          'salt' => "asdf@123",
   //          'cost' => 12
	  //       ];
	  //       $hash = password_hash($_REQUEST['pass'], PASSWORD_DEFAULT, $options);
	        $pass = md5($_REQUEST['pass']);

	        $_POST['pass'] = $pass;
	        
			if($db->insert("users",$_POST)){
				header("location:index.php");
			}
		}
		else{
			header("location:register.php");
		}
	}
	
?>