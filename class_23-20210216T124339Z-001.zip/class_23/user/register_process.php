<?php
	require('../config/db.php');
	require('../model/model.php');

	$db = new Model();

	if($db->insert("users",$_POST)){
		header("location:index.php");
	}
?>