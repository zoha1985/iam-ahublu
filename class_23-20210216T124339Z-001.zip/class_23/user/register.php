<!DOCTYPE html>
<html>
<head>
	<title>User register</title>
</head>
<body>
	<form action="register_process.php" method="post"> 
		<input type="text" name="full_name">
		<input type="email" name="email">
		<input type="password" name="pass">
		<input type="submit" value="Register">
		<a href="index.php">Login</a>
	</form>
</body>
</html>