<?php
require('../classes/session.php');
require('../config/db.php');
require('../model/model.php');
require('../classes/validation.php');

	$post_value = [
		["email","required:email"],
		["pass","required:password"]
	];
	$validate = new Validation($post_value);

	// check validation
	if($validate->isError()){
		echo $validate->isError();
	}
	else{
		$db= new Model;
        $pass = md5($_REQUEST['pass']);

	    $where = "email='".$_REQUEST['email']."' AND pass='". $pass ."'"; //"email='abc@gmail.com'"
		$get_email = $db->select("admin","email",$where);
		
		// echo $get_email['count'];
		// exit();
		if($get_email['count'] > 0){
			Session::init();
			Session::setValue("email",$_REQUEST['email']);
			header("location:dashboard.php");
		}
		else{
			header("location:index.php");
		}
	}
?>