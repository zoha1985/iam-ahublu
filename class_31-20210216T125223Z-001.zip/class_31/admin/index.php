<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
</head>
<body>
	<form action="login_process.php" method="post"> 
		<input type="email" name="email">
		<input type="password" name="pass">
		<input type="submit" value="Login">
	</form>
</body>
</html>