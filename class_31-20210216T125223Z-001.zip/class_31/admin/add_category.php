<?php
	require('../classes/session.php');
	require('../classes/views.php');
	
	Session::init();

	if(!Session::checkSession('email')){
		header("location:index.php");
	}

	$where = "email='".Session::getValue("email")."'";

	$view = new Views();
	$view->render("add_category",false,"admin/");
?>
