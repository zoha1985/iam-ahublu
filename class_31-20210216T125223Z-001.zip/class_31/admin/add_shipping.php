<?php
	require('inc.php');

	$view = new Views();
	$view->render("add_shipping",false,"admin/");