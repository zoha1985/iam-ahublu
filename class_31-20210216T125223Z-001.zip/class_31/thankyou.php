<?php require("public/header.php"); ?>
<h1 align="center">Thank you for your order!</h1>
<?php require("public/footer.php"); ?>