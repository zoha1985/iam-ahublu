<?php require("public/header.php"); ?>
<?php
	$sub_total = 0;
	// Users ----
	$u_email = Session::getValue("email");
	$where = "email='".$u_email."'";
	$user = $db->select("users","*",$where);
	$user = $user['rows'][0];

	// Shipping ---
	$where = "s_city='".$user['city']."'";
	$get_shipping = $db->select("shipping","*",$where);

	// Payment Method
	$get_pay = $db->select("paymethod","*");

	// Cart ---
	$where = "u_email='".$u_email."'";
	$get_data = $db->select("cart","*",$where);
		
	
?>
<h3>Cart page</h3>
<?php
	if($get_data['count'] == 0){
		echo '<h1 align="center">Cart is empty!</h1>';
	}
	else{
?>

<strong>Name: </strong><?php echo $user['full_name']; ?><br>
<strong>Shipping Address: </strong><?php echo $user['address'].", ".$user['city'].", ".$user['country']; ?><br>
<strong>Email: </strong><?php echo $user['email']; ?><br>
<strong>Phone: </strong><?php echo $user['phone']; ?>
<P>&nbsp;</P>
<table width="600">
	<tr>
		<th align="left">Product Name </th>
		<th align="left">Price </th>
		<th align="left">Qty. </th>
		<th align="left">Total</th>
		<th align="left">Action</th>
	</tr>
<?php
	foreach ($get_data["rows"] as $value) {
?>
	<tr>
		<td><?php echo $value['p_name']; ?></td>
		<td><?php echo $value['p_price']; ?></td>
		<td><?php echo $value['qty']; ?></td>
		<td><?php echo $value['price_total']; ?></td>
		<td><a href="#">_X_</a></td>
	</tr>
<?php
	$sub_total += $value['price_total'];
	}
?>
	<tr>
		<td colspan="5"><hr></td>
	</tr>
	<tr>
		<td></td>
		<td colspan="2">Sub Total:</td>
		<td><?php echo $sub_total; ?></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td colspan="2">Shipping Charge:</td>
		<td><?php echo $get_shipping['rows'][0]['s_rate']; ?></td>
		<td></td>
	</tr>
	<tr>
		<td colspan="5"><hr></td>
	</tr>
	<tr>
		<td></td>
		<td colspan="2">Total:</td>
		<td><?php echo ($sub_total + $get_shipping['rows'][0]['s_rate']); ?></td>
		<td></td>
	</tr>
	<tr>
		<td colspan="5">
			<form action="public/process/checkout_process.php" method="post">
				<input type="hidden" name="shipping_cost" value="<?php echo $get_shipping['rows'][0]['s_rate']; ?>">
				<input type="hidden" name="final_total" value="<?php echo ($sub_total + $get_shipping['rows'][0]['s_rate']); ?>">
				<?php
					foreach ($get_pay['rows'] as $value) {
						if($value['pay_method'] === "Cash on Delivery"){
							echo '<input type="radio" name="pay_method" value="'.$value['pay_method'].'" checked>'
							.$value['pay_method'].'<br>';
						}
						else{
							echo '<input type="radio" name="pay_method" value="'.$value['pay_method'].'">'
							.$value['pay_method'].'<br>';
						}
					}
				?>
				<p>&nbsp;</p>
				<input type="submit" value="Check Out">
			</form>
		</td>
	</tr>
</table>
<?php } require("public/footer.php"); ?>