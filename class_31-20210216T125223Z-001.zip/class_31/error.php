<?php require("public/header.php"); ?>
<h1 align="center">Purchasing Error!</h1>
<?php require("public/footer.php"); ?>