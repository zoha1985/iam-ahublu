<?php
	if(Session::checkSession("email")){
?>
<a href="cart.php">Cart</a> | 
<a href="user/profile.php">Profile</a> | 
<a href="user/update.php">Update</a> | 
<a href="user/logout.php">Logout</a> 
<?php
	}
	else{
?>
<a href="user/index.php">User</a>
<a href="user/register.php">Register</a>
<?php		
	}
?>
