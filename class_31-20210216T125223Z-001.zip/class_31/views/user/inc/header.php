<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
</head>
<body>
	<table>
		<tr>
			<td>
				<?php require("nav.php"); ?>
			</td>
			<td>