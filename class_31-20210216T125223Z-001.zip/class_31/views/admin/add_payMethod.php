<?php require("inc/header.php"); ?>
<form action="add_payMethod_process.php" method="post">
	<table>
		<tr>
			<td>Payment Method:</td>
			<td><input type="text" name="pay_method"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="Submit"></td>
		</tr>
	</table>	
</form>

<?php require("inc/footer.php"); ?>