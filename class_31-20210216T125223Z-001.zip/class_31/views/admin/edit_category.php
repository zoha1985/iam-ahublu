<?php require("inc/header.php"); ?>
<?php $value = $this->data['rows'][0]; ?>
<form action="edit_category_process.php?cid=<?php echo $value['cid']; ?>" method="post">
	<table>
		<tr>
			<td>Category name:</td>
			<td><input type="text" name="cat_name" value="<?php echo $value['cat_name']; ?>"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="Submit"></td>
		</tr>
	</table>	
</form>

<?php require("inc/footer.php"); ?>