<?php require("inc/header.php"); ?>
<?php $value = $this->data['rows']; ?>
<table class="content">
	<tr>
		<th>Rated</th>
		<th>City</th>
		<th>Method</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	<?php
		foreach ($value as $val) {
	?>
		<tr>
			<td><?php echo $val['s_rate']; ?></td>
			<td><?php echo $val['s_city']; ?></td>
			<td><?php echo $val['s_method']; ?></td>
			<td><a href="edit_shipping.php?sid=<?php echo $val['sid']; ?>">Edit</a></td>
			<td><a href="del_shipping_process.php?sid=<?php echo $val['sid']; ?>">Delete</a></td>
		</tr>
	<?php
		}
	?>
</table>
<?php require("inc/footer.php"); ?>