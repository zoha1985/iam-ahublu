<?php require("inc/header.php"); ?>
<form action="add_shipping_process.php" method="post">
	<table>
		<tr>
			<td>Country:</td>
			<td><input type="text" name="s_country"></td>
		</tr>
		<tr>
			<td>City:</td>
			<td><input type="text" name="s_city"></td>
		</tr>
		<tr>
			<td>Rate:</td>
			<td><input type="text" name="s_rate"></td>
		</tr>
		<tr>
			<td>Method:</td>
			<td><input type="text" name="s_method"></td>
		</tr>
		<tr>
			<td>Shipping Time:</td>
			<td><input type="text" name="s_time"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="Submit"></td>
		</tr>
	</table>	
</form>

<?php require("inc/footer.php"); ?>