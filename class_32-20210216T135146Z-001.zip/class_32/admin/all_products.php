<?php
	require('inc.php');

	$db = new Model();
	$all_products = $db->select("products","*");

	$view = new Views();
	$view->render("all_products",$all_products,"admin/");