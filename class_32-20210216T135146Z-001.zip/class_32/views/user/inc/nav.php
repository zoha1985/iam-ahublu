<ul>
	<li><a href="../index.php">Home</a></li>
	<li><a href="profile.php">Profile</a></li>
	<li><a href="update.php">Update</a></li>
	<li><a href="logout.php">Logout</a></li>
</ul>