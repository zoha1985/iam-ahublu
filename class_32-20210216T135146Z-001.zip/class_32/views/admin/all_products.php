<?php require("inc/header.php"); ?>
<?php $value = $this->data['rows']; ?>
<table class="content">
	<tr>
		<th>Product name</th>
		<th>Product cat</th>
		<th>Product price</th>
		<th>Product stock</th>
		<th>Product brand</th>
		<th>Product image</th>
		<th>Actions</th>
	</tr>
	<?php
		foreach ($value as $val) {
	?>
		<tr>
			<td><?php echo $val['p_name']; ?></td>
			<td><?php echo $val['cid']; ?></td>
			<td><?php echo $val['p_price']; ?></td>
			<td><?php echo $val['p_stock']; ?></td>
			<td><?php echo $val['p_brand']; ?></td>
			<td>
				<img src="<?php echo "../assets/products/".$val['p_pic']; ?>" width="50">
			</td>
			<td>
				<a href="edit_product.php?pid=<?php echo $val['pid']; ?>">Edit</a> |
				<a href="del_product_process.php?pid=<?php echo $val['pid']; ?>">Delete</a>
			</td>
		</tr>
	<?php
		}
	?>
</table>
<?php require("inc/footer.php"); ?>