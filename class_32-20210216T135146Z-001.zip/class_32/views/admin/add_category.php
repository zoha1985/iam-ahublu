<?php require("inc/header.php"); ?>
<form action="add_category_process.php" method="post">
	<table>
		<tr>
			<td>Category name:</td>
			<td><input type="text" name="cat_name"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="Submit"></td>
		</tr>
	</table>	
</form>

<?php require("inc/footer.php"); ?>