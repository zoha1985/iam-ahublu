<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<link rel="stylesheet" type="text/css" href="../assets/style.css">
</head>
<body>
	<table>
		<tr>
			<td>
				<?php require("nav.php"); ?>
			</td>
			<td>