<?php
	require('classes/session.php');
	require('config/db.php');
	require('model/model.php');
	function dd($v){
		echo "<pre>";
		print_r($v);
		echo "</pre>";
	}
	Session::init();
	$db = new Model();

	$categories = $db->select("categories","*");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<style type="text/css">
		.prd{
			float: left;
			margin: 5px;
			padding: 5px;
			border: 1px solid #ccc;
			text-align: center;
			list-style-type: none;
		}
	</style>
</head>
<body>
	<?php require("public/nav.php"); ?>
	<table>
		<tr>
			<td>
				<ul>
				<?php
					foreach ($categories["rows"] as $value) {
					echo "<li><a href='index.php?cid=".$value["cid"]."'>".$value["cat_name"]."</a></li>";
					}
				?>
				</ul>
			</td>
			<td>