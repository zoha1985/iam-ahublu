-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 10, 2021 at 02:32 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydbpdo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(2) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `name`, `email`, `pass`) VALUES
(1, 'Mahbub', 'admin@gmail.com', '39bb37cf36d3b29a9280d8a70a0eed42');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `crt_id` int(11) NOT NULL,
  `u_email` varchar(200) NOT NULL,
  `pid` int(11) NOT NULL,
  `p_name` varchar(200) NOT NULL,
  `p_price` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price_total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`crt_id`, `u_email`, `pid`, `p_name`, `p_price`, `qty`, `price_total`) VALUES
(7, 'abmahbub08@gmail.com', 2, 'Keyboard', 400, 1, 400);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cid` int(11) NOT NULL,
  `cat_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cid`, `cat_name`) VALUES
(3, 'Electronics'),
(4, 'Cloth'),
(5, 'Grocery');

-- --------------------------------------------------------

--
-- Table structure for table `paymethod`
--

CREATE TABLE `paymethod` (
  `pay_id` int(3) NOT NULL,
  `pay_method` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `paymethod`
--

INSERT INTO `paymethod` (`pay_id`, `pay_method`) VALUES
(1, 'SSLCommerz'),
(2, 'Cash on Delivery');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `p_name` varchar(200) NOT NULL,
  `p_price` int(8) NOT NULL,
  `p_desc` longtext NOT NULL,
  `p_brand` varchar(200) NOT NULL,
  `p_stock` int(5) NOT NULL,
  `p_pic` varchar(200) NOT NULL,
  `p_gallery` varchar(240) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `cid`, `p_name`, `p_price`, `p_desc`, `p_brand`, `p_stock`, `p_pic`, `p_gallery`) VALUES
(1, 3, 'Laptop', 50000, 'This a super Laptop.', 'Lenovo', 0, 'laptop.png', ''),
(2, 3, 'Keyboard', 400, 'This is a key board.', 'A4Tech', 30, 'LenovoKeyboard.jpg', ''),
(4, 4, 'shirt', 600, 'sdfsdf', 'Cats Eye', 20, 'men-s-trekking-shirt-travel-100-warm-maroon.jpg', ''),
(5, 5, 'Potato', 30, 'sdfsfds', 'Khete Alu', 200, 'image.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `sid` int(3) NOT NULL,
  `s_rate` int(5) NOT NULL,
  `s_city` varchar(200) NOT NULL,
  `s_country` varchar(200) NOT NULL,
  `s_time` int(5) NOT NULL,
  `s_method` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shipping`
--

INSERT INTO `shipping` (`sid`, `s_rate`, `s_city`, `s_country`, `s_time`, `s_method`) VALUES
(1, 200, 'Khulna', 'Bangladesh', 1, 'SA Paribahan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_checkout`
--

CREATE TABLE `tbl_checkout` (
  `ch_id` int(11) NOT NULL,
  `order_ids` text NOT NULL,
  `u_email` varchar(200) NOT NULL,
  `shipping_cost` int(11) NOT NULL,
  `pay_method` varchar(200) NOT NULL,
  `final_total` int(11) NOT NULL,
  `order_status` varchar(200) NOT NULL,
  `checkout_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_checkout`
--

INSERT INTO `tbl_checkout` (`ch_id`, `order_ids`, `u_email`, `shipping_cost`, `pay_method`, `final_total`, `order_status`, `checkout_time`) VALUES
(2, '7,8,9', 'abmahbub08@gmail.com', 200, 'Cash on Delivery', 51830, 'pending', '2021-09-02 14:56:39'),
(3, '10', 'abmahbub08@gmail.com', 200, 'Cash on Delivery', 1400, 'pending', '2021-10-02 12:21:37'),
(4, '14', 'abmahbub08@gmail.com', 200, 'Cash on Delivery', 100200, 'confirm', '2021-10-02 12:34:47'),
(5, '15', 'abmahbub08@gmail.com', 200, 'Cash on Delivery', 900200, 'pending', '2021-10-02 12:42:51');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `or_id` int(11) NOT NULL,
  `u_email` varchar(200) NOT NULL,
  `pid` int(11) NOT NULL,
  `p_name` varchar(200) NOT NULL,
  `p_price` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price_total` int(11) NOT NULL,
  `order_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`or_id`, `u_email`, `pid`, `p_name`, `p_price`, `qty`, `price_total`, `order_time`) VALUES
(7, 'abmahbub08@gmail.com', 1, 'Laptop', 50000, 1, 50000, '2021-09-02 14:56:39'),
(8, 'abmahbub08@gmail.com', 2, 'Keyboard', 400, 4, 1600, '2021-09-02 14:56:39'),
(9, 'abmahbub08@gmail.com', 5, 'Potato', 30, 1, 30, '2021-09-02 14:56:39'),
(10, 'abmahbub08@gmail.com', 4, 'shirt', 600, 2, 1200, '2021-10-02 12:21:37'),
(14, 'abmahbub08@gmail.com', 1, 'Laptop', 50000, 2, 100000, '2021-10-02 12:34:47'),
(15, 'abmahbub08@gmail.com', 1, 'Laptop', 50000, 18, 900000, '2021-10-02 12:42:51');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transections`
--

CREATE TABLE `tbl_transections` (
  `t_id` int(11) NOT NULL,
  `ch_id` int(11) NOT NULL,
  `pay_method` varchar(100) NOT NULL,
  `trans_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_transections`
--

INSERT INTO `tbl_transections` (`t_id`, `ch_id`, `pay_method`, `trans_time`) VALUES
(1, 3, 'Cash on Delivery', '2021-10-02 12:21:37'),
(2, 4, 'Cash on Delivery', '2021-10-02 12:34:47'),
(3, 5, 'Cash on Delivery', '2021-10-02 12:42:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `phone` varchar(24) NOT NULL,
  `address` varchar(240) NOT NULL,
  `city` varchar(200) NOT NULL,
  `country` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `full_name`, `email`, `pass`, `phone`, `address`, `city`, `country`) VALUES
(1, 'Mohammad Mahbub1', 'abmahbub08@gmail.com', '39bb37cf36d3b29a9280d8a70a0eed42', '+8801911550799', '28 Darus Salam Masjid Lane', 'Khulna', 'Bangladesh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`crt_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `paymethod`
--
ALTER TABLE `paymethod`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `tbl_checkout`
--
ALTER TABLE `tbl_checkout`
  ADD PRIMARY KEY (`ch_id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`or_id`);

--
-- Indexes for table `tbl_transections`
--
ALTER TABLE `tbl_transections`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `crt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `paymethod`
--
ALTER TABLE `paymethod`
  MODIFY `pay_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `shipping`
--
ALTER TABLE `shipping`
  MODIFY `sid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_checkout`
--
ALTER TABLE `tbl_checkout`
  MODIFY `ch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `or_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_transections`
--
ALTER TABLE `tbl_transections`
  MODIFY `t_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
