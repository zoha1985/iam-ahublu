<?php require("public/header.php"); ?>
<ul>
	<?php
		if(isset($_GET['cid'])){
			$cid = $_GET['cid'];
		}
		else{
			$cid = $categories["rows"][0]["cid"];
		}

		$arg = [
			"cols" =>"*",
			"tables" => ["categories","products"],
		 	"join" => "categories.cid=products.cid",
			"where" => [
				["categories.cid","=",$cid]
			]
		];
		$products = $db->innerJoin($arg);

		foreach ($products["rows"] as $value) {
	?>
	<li class='prd'>
		<img src="assets/products/<?php echo $value['p_pic']; ?>" height="100"><br>
		<?php echo $value['p_name']; ?><br>
		<strong>Price: </strong><?php echo $value['p_price']; ?><br>
		<strong>Stock: </strong><?php echo $value['p_stock']; ?><br>
		<a href="public/process/cart_process.php?pid=<?php echo $value['pid']; ?>">Add to cart</a> | <a href="single_product.php?pid=<?php echo $value['pid']; ?>">View</a>
	</li>
	<?php
		}
	?>
</ul>
<?php require("public/footer.php"); ?>