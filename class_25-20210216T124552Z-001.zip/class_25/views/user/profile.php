<?php require("inc/header.php"); ?>
<?php $value = $this->data['rows'][0]; ?>
<table>
	<tr>
		<td>Full name:</td>
		<td><?php echo $value['full_name']; ?></td>
	</tr>
	<tr>
		<td>Email:</td>
		<td><?php echo $value['email']; ?></td>
	</tr>
</table>
<?php require("inc/footer.php"); ?>