<ul>
	<li><a href="logout.php">Logout</a></li>
</ul>