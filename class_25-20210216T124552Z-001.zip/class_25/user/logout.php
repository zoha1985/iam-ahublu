<?php
require('../classes/session.php');
session::init();
session::destroyValues();

header("location:index.php");

?>