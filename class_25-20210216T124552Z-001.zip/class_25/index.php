<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>
	<a href="user/index.php">User</a>
	<a href="admin/index.php">Admin</a>
</body>
</html>