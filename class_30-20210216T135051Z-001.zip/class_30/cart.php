<?php require("public/header.php"); ?>
<h3>Cart page</h3>
<table>
<?php

	$u_email = Session::getValue("email");
	$where = "u_email='".$u_email."'";
	$get_data = $db->select("cart","*",$where);
		// dd($products);
		// exit();

	foreach ($get_data["rows"] as $value) {
?>
	<tr>
		<td><?php echo $value['p_name']; ?></td>
		<td><?php echo $value['p_price']; ?></td>
		<td><?php echo $value['qty']; ?></td>
		<td><?php echo $value['price_total']; ?></td>
		<td><a href="#">_X_</a></td>
	</tr>
<?php
	}
?>
	<tr>
		<td colspan="5" align="center">
			<a href="#">Checkout</a>
		</td>
	</tr>
</table>
<?php require("public/footer.php"); ?>