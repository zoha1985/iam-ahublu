<?php require("inc/header.php"); ?>
<?php $value = $this->data['rows'][0]; ?>
<form action="update_process.php" method="POST">
	<table>
		<tr>
			<td>Full name:</td>
			<td><input type="text" name="full_name" value="<?php echo $value['full_name']; ?>"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="Update"></td>
		</tr>
	</table>
</form>

<?php require("inc/footer.php"); ?>