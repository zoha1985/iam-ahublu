<!DOCTYPE html>
<html>
<head>
	<title>User register</title>
</head>
<body>
	<form action="register_process.php" method="post"> 
		<input type="text" name="full_name" placeholder="full name">
		<input type="email" name="email" placeholder="email">
		<input type="password" name="pass" placeholder="password">
		<input type="submit" value="Register">
		<a href="index.php">Login</a>
	</form>
</body>
</html>