<a href="user/index.php">User</a>
<a href="admin/index.php">Admin</a>