<?php
	require('inc.php');

	$db = new Model();
	
	$arg = [
		"cols" =>"*",
		"tables" => ["categories","products"],
	 	"join" => "categories.cid=products.cid",
		"where" => [
			["categories.cid","=","3"]
		]
	];
	$data = $db->innerJoin($arg);
	dd($data);
	
	// $view = new Views();
	// $view->render("dashboard",$user_data,"admin/");
?>
