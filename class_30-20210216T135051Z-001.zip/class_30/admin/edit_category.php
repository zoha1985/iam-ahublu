<?php
	require('inc.php');

	$post_value = [
		["cid","required"]
	];
	$validate = new Validation($post_value);

	// check validation
	if($validate->isError()){
		echo $validate->isError();
	}
	else{
		$db = new Model();
		$where = "cid='".$_REQUEST['cid']."'";
		$category = $db->select("categories","*",$where);

		$view = new Views();
		$view->render("edit_category",$category,"admin/");
	}