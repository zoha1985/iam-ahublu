<?php
	require('inc.php');

	$db = new Model();
	$where = "email='".Session::getValue("email")."'";
	$user_data = $db->select("admin","*",$where);

	$view = new Views();
	$view->render("dashboard",$user_data,"admin/");
?>
