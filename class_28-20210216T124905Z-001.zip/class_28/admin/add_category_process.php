<?php
	require('../classes/session.php');
	require('../config/db.php');
	require('../model/model.php');
	require('../classes/validation.php');
	
	Session::init();

	if(!Session::checkSession('email')){
		header("location:index.php");
	}

	$post_value = [
		["cat_name","required"]
	];

	$validate = new Validation($post_value);

	// check validation
	if($validate->isError()){
		echo $validate->isError();
	}
	else{
		$db = new Model();
		$where = "cat_name='".$_REQUEST['cat_name']."'";
		$get_email = $db->select("categories","cat_name",$where);
		if($get_email['count'] > 0){
			header("location:add_category.php");
		}
		else{
			if($db->insert("categories",$_POST)){
				header("location:all_categories.php");
			}
			else{
				header("location:add_category.php");
			}
		}	
	}
?>
