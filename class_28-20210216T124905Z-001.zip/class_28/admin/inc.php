<?php
	require('../classes/session.php');
	require('../config/db.php');
	require('../model/model.php');
	require('../classes/views.php');
	require('../classes/validation.php');
	
	Session::init();

	if(!Session::checkSession('email')){
		header("location:index.php");
	}