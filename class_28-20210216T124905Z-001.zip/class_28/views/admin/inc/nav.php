<ul class="nav">
	<li><a href="dashboard.php">Dashboard</a></li>
	<li>Categories
		<ul>
			<li><a href="all_categories.php">All Categories</a></li>
			<li><a href="add_category.php">Add Category</a></li>
		</ul>
	</li>
	<li>Products
		<ul>
			<li><a href="all_products.php">All Products</a></li>
			<li><a href="add_product.php">Add Product</a></li>
		</ul>
	</li>
	<li><a href="logout.php">Logout</a></li>
</ul>