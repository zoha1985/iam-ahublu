<?php require("inc/header.php"); ?>
<?php $value = $this->data['rows']; ?>
<form action="add_product_process.php" method="post" enctype="multipart/form-data">
	<table>
		<tr>
			<td>Product name:</td>
			<td><input type="text" name="p_name"></td>
		</tr>
		<tr>
			<td>Product Category:</td>
			<td>
				<select name="cid">
					<option value="">Select a category</option>
					<?php
						foreach ($value as $v) {
							echo '<option value="'.$v['cid'].'">'.$v['cat_name'].'</option>';
						}
					?>
				</select>				
			</td>
		</tr>
		<tr>
			<td>Product Price:</td>
			<td><input type="text" name="p_price"></td>
		</tr>
		<tr>
			<td>Product Description:</td>
			<td><textarea cols="35" rows="5" name="p_desc"></textarea></td>
		</tr>
		<tr>
			<td>Product Brand:</td>
			<td><input type="text" name="p_brand"></td>
		</tr>
		<tr>
			<td>Product Stock:</td>
			<td><input type="number" name="p_stock"></td>
		</tr>
		<tr>
			<td>Product Image:</td>
			<td><input type="file" name="p_pic"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="Submit"></td>
		</tr>
	</table>	
</form>

<?php require("inc/footer.php"); ?>