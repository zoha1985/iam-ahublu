<?php
	class Validation{

		private $error = "";
		private $is_error = false;

		/*$post_value = [
			["email","required:email"],
			["pass","required:password"],
		];*/

		public function __construct($post_value){

			foreach ($post_value as $value) {
				$rules = explode(":",$value[1]);  // required | email

				foreach ($rules as $v) {         // $v = required | email | password
					if($v == "required"){
						$this->required($_REQUEST[$value[0]]); // $_POST["email"]
					}
					elseif($v == "email"){
						$this->email($_REQUEST[$value[0]]);
					}
					elseif($v == "password"){
						$this->password($_REQUEST[$value[0]]);
					}
				}
			}
		}

		// Required validation
		public function required($val){
			if(isset($val) && !empty($val)){
				return true;
			}
			$this->is_error = true;
			$this->error .= "Required.<br>";
		}

		// Email validation
		public function email($email){
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				if(!$this->is_error){
					$this->error .= "Invalid Email.<br>";
				}
				
				$this->is_error = true;
			}
			else{
				return true;
			}			
		}

		// Password validation
		public function password($pass){
			$uppercase = preg_match('@[A-Z]@', $pass);
			$lowercase = preg_match('@[a-z]@', $pass);
			$number = preg_match('@[0-9]@', $pass);

			if(!$uppercase || !$lowercase || !$number || strlen($pass) < 8){
				if(!$this->is_error){
					$this->error .= "Password Should at-least contain 1 Uppercase, 1 Lower case, 1 Number and not less than 8 charechters.<br>";
				}				
				$this->is_error = true;
			}
			else{
				return true;
			}			
		}


		public function isError(){
			if($this->is_error){
				return $this->error;
			}
			return false;
		}
	}
?>