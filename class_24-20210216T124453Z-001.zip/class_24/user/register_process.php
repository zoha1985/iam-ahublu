<?php
	require('../config/db.php');
	require('../model/model.php');
	require('../classes/velidation.php');

	$post_value = [
		["full_name","required"],
		["email","required:email"],
		["pass","required:password"]
	];

	$validate = new Validation($post_value);

	if($validate->isError()){
		echo $validate->isError();
	}
	else{

		 $options = [
            'salt' => "asdf@123",
            'cost' => 12
        ];
        $hash = password_hash($_REQUEST['pass'], PASSWORD_DEFAULT, $options);
        $pass = md5($hash);

        $_POST['pass'] = $pass;

        $db = new Model();
		if($db->insert("users",$_POST)){
			header("location:index.php");
		}
	}
	
?>