<?php
	require('../config/db.php');
	require('../model/model.php');

	$db = new Model();
	$multipleArray = $db->select("users","full_name","","full_name","DESC","0,2");

	foreach ($multipleArray as $key => $value) {
		foreach ($value as $k => $v) {
			echo $k ."=>". $v."<br>";
		}
		echo "<hr>";
	}

?>