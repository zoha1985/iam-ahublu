<?php
class Model extends Database{
	//$tbl = user
	//$_POST = array("name"=>"kamal","email"=>"abc@gmail.com","pass"=>"as12")

	public function insert($tbl,$data){

		$columns = "";
		$values = "";
		$bind = array();

		foreach($data as $col=>$val){
			$columns .= $col.",";
			$values .= "?,";
			$bind[] = $val;
			//$values .= "'".$val."',";
		}

		$columns = "(".substr($columns,0,-1).")";
		$values = "VALUES(".substr($values,0,-1).")";

		//insert into tbl(a,b) values(?,?)			
		$sql = "INSERT INTO ".$tbl.$columns." ".$values;
		$stmt = $this->conn->prepare($sql);
			if($stmt->execute($bind)){
				return true;
			}
		return false;
	}


	// SELECT v1_columns FROM v2_tbl WHERE v3_logic ORDER BY v4_column v5_asc/v5_desc LIMIT v6_limit  
	public function select($tbl,$columns="*",$where="",$orderby_column="",$asc_desc="",$limit=""){
		$sql = "SELECT ";

		if($columns != "*"){
			$sql .= $columns." FROM ".$tbl;
		}
		else{
		  $sql = "SELECT * FROM ".$tbl;
		}

		if($where != ""){
			$sql .= " WHERE ".$where;
		}

		if($orderby_column != ""){
			$sql .= " ORDER BY ".$orderby_column;
		}

		if($asc_desc != ""){
			$sql .= " ".$asc_desc;
		}

		if($limit != ""){
			$sql .= " LIMIT ".$limit;
		}

		$stmt = $this->conn->prepare($sql);
		$stmt->execute();
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		$row = $stmt->fetchAll();

		return $row;
		//print_r($row);
	}

	/* $col_data = array(
		"full_name" => "Kamal",
		"email" => "abc@gmail.com"
	);*/

	//UPDATE tbl SET col_1=?,col_2=? WHERE id=?
	public function update($tbl, $col_data, $where){
		$sql = "UPDATE ".$tbl." SET ";
		$col = "";
		$val = array();

		foreach ($col_data as $key => $value) {
			$col .= $key."=?,";
			$val[] = $value;
		}

		$col = substr($col, 0,-1)." ";
		$sql .=  $col." WHERE ".$where;


		$stmt = $this->conn->prepare($sql);
		if($stmt->execute($val)){
			return true;
		}
		return false;
	}


	public function delete($tbl,$where){
		$sql = "DELETE FROM ".$tbl." WHERE ".$where;

		$stmt = $this->conn->prepare($sql);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

}

?>